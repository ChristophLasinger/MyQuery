# webapp-weather-lasinger-kern
webapp-weather-lasinger-kern created by GitHub Classroom
The user is able to either select a city on a map of the world or enter the name of a city (optionally the user can add the ISO 3166 country code of the country the city is in, to specify which city) and the webapp will provide some weather-related data about the city.
The source of the data is an API called openweathermap.
When the user visits the webside there will be a login button and when logged in the user can provide feedback on how accurate the data for a certain location is.
